"""
Package containing a demo room and some stuff, to easily check out
a running Tale framework (python -m tale.demo.story)

'Tale' mud driver, mudlib and interactive fiction framework
Copyright by Irmen de Jong (irmen@razorvine.net)
"""
