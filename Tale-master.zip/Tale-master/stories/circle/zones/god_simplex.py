from .circledata.circle_locations import make_location

zone_vnum = 12   # god simplex
boardroom_vnum = 1204    # start room for wizards
icebox_vnum = 1202   # start room for frozen


boardroom = make_location(boardroom_vnum)

icebox = make_location(icebox_vnum)
