from .circledata.circle_locations import make_location

zone_vnum = 30   # midgaard city
temple_vnum = 3001

temple = make_location(temple_vnum)
